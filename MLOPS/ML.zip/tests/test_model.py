# tests/test_model.py
import unittest
from model import train_model
import pandas as pd

class TestModel(unittest.TestCase):
    def test_train_model(self):
        data = pd.DataFrame({
            'feature1': [1, 2, 3, 4],
            'feature2': [10, 20, 30, 40],
            'target': [0, 1, 0, 1]
        })
        model = train_model(data)
        self.assertIsNotNone(model)

if __name__ == '__main__':
    unittest.main()
