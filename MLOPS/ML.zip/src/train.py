# src/train.py
import pandas as pd
from model import train_model

def main():
    # Load the dataset with UTF-8 encoding
    data = pd.read_csv('data/sample_data.csv', encoding='utf-8')
    # Train the model
    model = train_model(data)
    # Save the trained model
    model.save('outputs/model.pkl')

if __name__ == '__main__':
    main()
