# src/evaluate.py
import pandas as pd
from model import load_model, evaluate_model

def main():
    # Load the dataset with UTF-8 encoding
    data = pd.read_csv('data/sample_data.csv', encoding='utf-8')
    # Load the trained model
    model = load_model('outputs/model.pkl')
    # Evaluate the model
    metrics = evaluate_model(model, data)
    # Save the evaluation metrics
    with open('outputs/metrics.json', 'w', encoding='utf-8') as f:
        f.write(str(metrics))

if __name__ == '__main__':
    main()
