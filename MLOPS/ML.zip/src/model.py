# src/model.py
import pickle
from sklearn.linear_model import LogisticRegression

def train_model(data):
    X = data.drop('target', axis=1)
    y = data['target']
    model = LogisticRegression()
    model.fit(X, y)
    return model

def load_model(model_path):
    with open(model_path, 'rb') as f:
        model = pickle.load(f)
    return model

def evaluate_model(model, data):
    X = data.drop('target', axis=1)
    y = data['target']
    accuracy = model.score(X, y)
    return {'accuracy': accuracy}
