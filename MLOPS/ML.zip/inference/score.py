# inference/score.py
import json
import pandas as pd
from model import load_model

def init():
    global model
    model_path = 'outputs/model.pkl'
    model = load_model(model_path)

def run(raw_data):
    data = pd.DataFrame(json.loads(raw_data))
    predictions = model.predict(data)
    return predictions.tolist()
